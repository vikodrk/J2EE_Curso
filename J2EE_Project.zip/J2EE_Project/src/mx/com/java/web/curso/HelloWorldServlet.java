package mx.com.java.web.curso;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Para declarar un Servlet se debe de extender de la clase {@link HttpServlet}
 */
public class HelloWorldServlet extends HttpServlet {

    /**
     * 
     */
    private static final long serialVersionUID = -6925015381793759835L;

    /*
     * Se hace una sobreescritura de los metodos doGet y doPost del Objeto
     * HttpServlet.
     */

    public void doGet(HttpServletRequest req, HttpServletResponse res) {

        System.out.println("Ingresando al servlet HelloWorldServlet");
    }

    public void doPost(HttpServletRequest req, HttpServletResponse res) {

        doGet(req, res);
    }

}
