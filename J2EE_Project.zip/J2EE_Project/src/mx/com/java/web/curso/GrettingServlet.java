package mx.com.java.web.curso;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet para la recuperacion de parametros desde url (get).
 *
 */
public class GrettingServlet extends HttpServlet {

    /**
     * 
     */
    private static final long serialVersionUID = 4990578630986758444L;

    public void doGet(HttpServletRequest req, HttpServletResponse res) {

        System.out.println("Hola " + req.getParameter("nombre"));
    }

    public void doPost(HttpServletRequest req, HttpServletResponse res) {

        doGet(req, res);
    }

}
