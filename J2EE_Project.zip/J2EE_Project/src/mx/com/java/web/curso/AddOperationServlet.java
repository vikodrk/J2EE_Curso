package mx.com.java.web.curso;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet para la recuperacion de parametros desde url (get).
 *
 */
public class AddOperationServlet extends HttpServlet {

    /**
     * 
     */
    private static final long serialVersionUID = 4990578630986758444L;

    public void doGet(HttpServletRequest req, HttpServletResponse res) {

        int numero1;
        int numero2;
        
        numero1=Integer.parseInt(req.getParameter("numero1"));
        numero2=Integer.parseInt(req.getParameter("numero2"));
        
        System.out.println("La suma de "+numero1+" y de "+numero2+" es igual a: "+(numero1+numero2));
    }

    public void doPost(HttpServletRequest req, HttpServletResponse res) {

        doGet(req, res);
    }

}
