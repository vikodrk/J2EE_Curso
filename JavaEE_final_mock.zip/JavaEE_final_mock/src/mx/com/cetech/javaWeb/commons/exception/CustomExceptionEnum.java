package mx.com.cetech.javaWeb.commons.exception;

public enum CustomExceptionEnum {
	
	UNKNOWN_ERROR(-1,"Error desconocido."),
	DB_FILE_NOT_FOUND(1,"Archivo de configuracion de base de datos no encontrado."),
	DB_INSTANCIATION_ERROR(2,"Error al instanciar el Driver de Base de Datos."),
	DB_ILLEGAR_ACCESS_ERROR(3,"Error al acceder a la ubicacion del Driver de Base de Datos."),
	DB_DRIVER_NOT_FOUND(4,"No se encontro la clase del Driver de conexi�n a Base de Datos."),
	DB_CONNECTION_ERROR(5,"Error al generar la conexi�n a Base de Datos."),
	DB_CONNECTION_CLOSE_ERROR(6,"Error al cerrar la conexi�n a Base de Datos."),
	DB_ERROR(7,"Ocurrio un error al comunicarse con la Base de Datos."),
	DB_ERROR_RESULT(8,"Se produjo un error en la consulta."),
	DB_ERROR_ENTITY_EXISTS(9,"El registro ya existe.")
	
	;
	
	private int code;
	private String description;
	
	private CustomExceptionEnum(int code,String description)
	{
		this.code=code;
		this.description = description;
	}
	
	public int getCode(){
		return code;
	}
	
	public String getDescription()
	{
		return description;
	}

}
