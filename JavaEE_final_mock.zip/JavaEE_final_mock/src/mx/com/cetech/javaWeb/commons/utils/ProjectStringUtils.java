package mx.com.cetech.javaWeb.commons.utils;

public final class ProjectStringUtils {

	public static String concatenateStrings(Object... obj) {
		StringBuilder builder = new StringBuilder();

		for (Object iterator : obj) {
			builder.append(validateObject(iterator));
		}

		return builder.toString();
	}

	public static String validateObject(Object obj, String stringIfNull) {
		return obj == null ? stringIfNull : String.valueOf(obj);
	}

	public static String validateObject(Object obj) {
		return validateObject(obj, "");
	}

}
