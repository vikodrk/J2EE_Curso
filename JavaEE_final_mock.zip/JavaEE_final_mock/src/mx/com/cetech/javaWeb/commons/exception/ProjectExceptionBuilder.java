package mx.com.cetech.javaWeb.commons.exception;

public final class ProjectExceptionBuilder {

	public static ProjectCustomException buildException(CustomExceptionEnum errorCode, Throwable e) {
		return new ProjectCustomException(errorCode, e);
	}

	public static ProjectCustomException buildException(CustomExceptionEnum errorCode) {
		return new ProjectCustomException(errorCode);
	}

	public static ProjectCustomException buildException() {
		return buildException(CustomExceptionEnum.UNKNOWN_ERROR);
	}

}
