package mx.com.cetech.javaWeb.commons.exception;

public class ProjectCustomException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3935639812067565102L;
	private CustomExceptionEnum exceptionTye;
	private int code;
	private String description;

	public ProjectCustomException(CustomExceptionEnum errorCode) {
		super(errorCode.getDescription());
		exceptionTye = errorCode;
		this.code = errorCode.getCode();
		this.description = errorCode.getDescription();
	}

	public ProjectCustomException(CustomExceptionEnum errorCode, Throwable e) {
		super(errorCode.getDescription(), e);
		this.exceptionTye = errorCode;
		this.code = errorCode.getCode();
		this.description = errorCode.getDescription();
	}

	public CustomExceptionEnum getErrorCode() {
		return exceptionTye;
	}

	public int getCode() {
		return code;
	}

	public String getDescription() {
		return description;
	}

}
