package mx.com.cetech.javaWeb.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import mx.com.cetech.javaWeb.web.enums.IFormsParameters;

public interface IService<T extends Serializable> {

	T buildEntityFromMap(Map<? extends IFormsParameters, Object> map);

	void create(T entity);

	void update(Serializable id, T newEntity);

	void deleteUser(T entity);

	List<T> findAll();

	T findById(Serializable id);

}
