package mx.com.cetech.javaWeb.service.impl;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import mx.com.cetech.javaWeb.commons.utils.ProjectStringUtils;
import mx.com.cetech.javaWeb.persistence.dao.impl.UserDAOImpl;
import mx.com.cetech.javaWeb.persistence.model.UserDO;
import mx.com.cetech.javaWeb.service.IService;
import mx.com.cetech.javaWeb.web.enums.IFormsParameters;
import mx.com.cetech.javaWeb.web.enums.UserParametersEnum;

public class UserServiceImpl implements IService<UserDO> {

	private static final Logger LOGGER = Logger.getLogger(UserServiceImpl.class);

	private UserDAOImpl userDAO = new UserDAOImpl();

	@Override
	public void create(UserDO entity) {

		userDAO.insertNewRecord(entity);

	}

	@Override
	public void update(Serializable id, UserDO newEntity) {

		userDAO.updateRecord(id, newEntity);

	}

	@Override
	public void deleteUser(UserDO entity) {

		userDAO.deleteRecord(entity);

	}

	@Override
	public List<UserDO> findAll() {
		return userDAO.findAll();
	}

	@Override
	public UserDO findById(Serializable id) {
		return userDAO.findById(id);
	}

	@Override
	public UserDO buildEntityFromMap(Map<? extends IFormsParameters, Object> map) {
		UserDO entity = new UserDO();

		entity.setUserName(ProjectStringUtils.validateObject(map.get(UserParametersEnum.NOMBRE_USUARIO), ""));
		entity.setPass(ProjectStringUtils.validateObject(map.get(UserParametersEnum.PASS), ""));
		entity.setType(
				Integer.parseInt(ProjectStringUtils.validateObject(map.get(UserParametersEnum.TIPO_USUARIO), "1")));

		LOGGER.debug("Entity -> " + entity);

		return entity;
	}

}
