package mx.com.cetech.javaWeb.service.impl;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import mx.com.cetech.javaWeb.commons.utils.ProjectStringUtils;
import mx.com.cetech.javaWeb.persistence.dao.impl.ProductDAOImpl;
import mx.com.cetech.javaWeb.persistence.model.ProductDO;
import mx.com.cetech.javaWeb.service.IService;
import mx.com.cetech.javaWeb.web.enums.IFormsParameters;
import mx.com.cetech.javaWeb.web.enums.ProductParametersEnum;

public class ProductServiceImpl implements IService<ProductDO> {

	private static final Logger LOGGER = Logger.getLogger(ProductServiceImpl.class);

	private ProductDAOImpl productDAO = new ProductDAOImpl();

	@Override
	public ProductDO buildEntityFromMap(Map<? extends IFormsParameters, Object> map) {
		ProductDO entity = new ProductDO();

		entity.setBuyPrice(
				Double.valueOf(ProjectStringUtils.validateObject(map.get(ProductParametersEnum.BUY_PRICE), "0.00")));
		entity.setSellPrice(
				Double.valueOf(ProjectStringUtils.validateObject(map.get(ProductParametersEnum.SELL_PRICE), "0.00")));
		entity.setQuantity(
				Integer.valueOf(ProjectStringUtils.validateObject(map.get(ProductParametersEnum.QUANTITY), "0")));
		entity.setDescription(ProjectStringUtils.validateObject(map.get(ProductParametersEnum.DESCRIPTION), "---"));
		entity.setId(ProjectStringUtils.validateObject(map.get(ProductParametersEnum.ID), "---"));
		entity.setName(ProjectStringUtils.validateObject(map.get(ProductParametersEnum.NAME), "---"));

		LOGGER.debug("Entity -> " + entity);

		return entity;
	}

	@Override
	public void create(ProductDO entity) {

		productDAO.insertNewRecord(entity);

	}

	@Override
	public void update(Serializable id, ProductDO newEntity) {

		productDAO.updateRecord(id, newEntity);
	}

	@Override
	public void deleteUser(ProductDO entity) {

		productDAO.deleteRecord(entity);

	}

	@Override
	public List<ProductDO> findAll() {

		return productDAO.findAll();
	}

	@Override
	public ProductDO findById(Serializable id) {

		return productDAO.findById(id);
	}

}
