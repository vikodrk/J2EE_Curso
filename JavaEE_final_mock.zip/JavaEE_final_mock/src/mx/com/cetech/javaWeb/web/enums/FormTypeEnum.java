package mx.com.cetech.javaWeb.web.enums;

@SuppressWarnings("rawtypes")
public enum FormTypeEnum {

	USER_FORM(UserParametersEnum.class),

	PRODUCT_FORM(ProductParametersEnum.class);

	private Class clazz;

	private FormTypeEnum(Class clazz) {
		this.clazz = clazz;
	}

	public Class getFormType() {
		return this.clazz;
	}

}
