package mx.com.cetech.javaWeb.web.servlets;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import mx.com.cetech.javaWeb.commons.utils.ProjectStringUtils;
import mx.com.cetech.javaWeb.web.enums.FormTypeEnum;
import mx.com.cetech.javaWeb.web.enums.IFormsParameters;
import mx.com.cetech.javaWeb.web.enums.ProductParametersEnum;
import mx.com.cetech.javaWeb.web.enums.UserParametersEnum;

public abstract class AbstractBaseServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8645405858644220016L;

	private FormTypeEnum formType;

	public AbstractBaseServlet(FormTypeEnum formType) {
		this.formType = formType;
	}

	private static final Logger LOGGER = Logger.getLogger(AbstractBaseServlet.class);

	public abstract void doGet(HttpServletRequest req, HttpServletResponse res);

	public abstract void doPost(HttpServletRequest req, HttpServletResponse res);

	protected Object getObjectFromSession(String key, HttpSession session) {
		LOGGER.debug("Retrieving Object from session: " + key);
		Object obj = null;
		obj = session.getAttribute(key);
		LOGGER.debug("The Object: " + obj);
		return obj;
	}

	protected void setObjectToSession(String key, Object obj, HttpSession session) {

		LOGGER.debug("Put Object on Session\nKey: " + key + "\nObject: " + obj);
		session.setAttribute(key, obj);

	}

	protected Map<? extends IFormsParameters, Object> getFormParameters(HttpServletRequest req) {

		Map<? extends IFormsParameters, Object> map = null;

		switch (formType) {
		case PRODUCT_FORM:
			map = buildProductMapParameters(req);
			break;
		case USER_FORM:
			map = buildUserMapParameters(req);
			break;
		default:
			break;
		}

		return map;
	}

	private Map<UserParametersEnum, Object> buildUserMapParameters(HttpServletRequest req) {
		Map<UserParametersEnum, Object> map = new HashMap<UserParametersEnum, Object>();

		UserParametersEnum[] values = UserParametersEnum.values();

		for (UserParametersEnum iterator : values) {
			LOGGER.debug("Parameter: " + iterator.name() + "\nValue: " + req.getParameter(iterator.getParameter()));
			map.put(iterator, req.getParameter(iterator.getParameter()));
		}

		return map;
	}

	private Map<ProductParametersEnum, Object> buildProductMapParameters(HttpServletRequest req) {
		Map<ProductParametersEnum, Object> map = new HashMap<ProductParametersEnum, Object>();

		ProductParametersEnum[] values = ProductParametersEnum.values();

		for (ProductParametersEnum iterator : values) {
			LOGGER.debug("Parameter: " + iterator.name() + "\nValue: " + req.getParameter(iterator.getParameter()));
			map.put(iterator, req.getParameter(iterator.getParameter()));
		}

		return map;
	}

	protected void redirect(HttpServletRequest req, HttpServletResponse res, String prefix, String destination,
			String subfix) {
		try {
			String url = ProjectStringUtils.concatenateStrings(prefix, "/", destination, ".", subfix);
			req.getRequestDispatcher(url).forward(req, res);
		} catch (ServletException | IOException e) {
			LOGGER.error(e.getMessage(), e);
		}
	}

}
