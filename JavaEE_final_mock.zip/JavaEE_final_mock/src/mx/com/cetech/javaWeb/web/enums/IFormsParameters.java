package mx.com.cetech.javaWeb.web.enums;

public interface IFormsParameters {

	String getParameter();

}
