package mx.com.cetech.javaWeb.web.servlets;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import mx.com.cetech.javaWeb.persistence.model.UserDO;
import mx.com.cetech.javaWeb.service.IService;
import mx.com.cetech.javaWeb.service.impl.UserServiceImpl;
import mx.com.cetech.javaWeb.web.enums.FormTypeEnum;
import mx.com.cetech.javaWeb.web.enums.IFormsParameters;

public class UserSignUpServlet extends AbstractBaseServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3491761912605444450L;

	private static final Logger LOGGER = Logger.getLogger(UserSignUpServlet.class);

	private IService<UserDO> service = new UserServiceImpl();

	public UserSignUpServlet() {
		super(FormTypeEnum.USER_FORM);
	}

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res);
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) {

		Map<? extends IFormsParameters, Object> map = getFormParameters(req);
		LOGGER.debug("The map->" + map);
		UserDO entity = service.buildEntityFromMap(map);
		service.create(entity);
		redirect(req, res, "", "index", "jsp");

	}

}
