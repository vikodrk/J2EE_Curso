package mx.com.cetech.javaWeb.web.servlets;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import mx.com.cetech.javaWeb.persistence.model.ProductDO;
import mx.com.cetech.javaWeb.service.IService;
import mx.com.cetech.javaWeb.service.impl.ProductServiceImpl;
import mx.com.cetech.javaWeb.web.enums.FormTypeEnum;

public class ProductSearch extends AbstractBaseServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4786265969359217892L;

	private static final Logger LOGGER = Logger.getLogger(ProductSearch.class);

	private IService<ProductDO> service = new ProductServiceImpl();

	public ProductSearch() {
		super(FormTypeEnum.PRODUCT_FORM);
	}

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub

	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) {

		List<ProductDO> list = service.findAll();
		LOGGER.debug("Product size: " + list.size());
		req.setAttribute("productResult", list);
		redirect(req, res, "", "index", "jsp");
	}

}
