package mx.com.cetech.javaWeb.web.enums;

public enum ProductParametersEnum implements IFormsParameters {

	ID("productId"),

	NAME("productName"),

	DESCRIPTION("productDescription"),

	QUANTITY("productQuantity"),

	BUY_PRICE("productBuyPrice"),

	SELL_PRICE("productSellPrice"),

	DATE("productDate")

	;

	private String parameter;

	private ProductParametersEnum(String parameter) {
		this.parameter = parameter;
	}

	@Override
	public String getParameter() {

		return this.parameter;
	}

}
