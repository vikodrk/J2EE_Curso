package mx.com.cetech.javaWeb.web.enums;

public enum UserParametersEnum implements IFormsParameters{

	NOMBRE_USUARIO("userName"),

	PASS("userPass"),

	TIPO_USUARIO("userType");

	private String parameter;

	private UserParametersEnum(String parameter) {
		this.parameter = parameter;
	}

	public String getParameter() {
		return parameter;
	}

}
