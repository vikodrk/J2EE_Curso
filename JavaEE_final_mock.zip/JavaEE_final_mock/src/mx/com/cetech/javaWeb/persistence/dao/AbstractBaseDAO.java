package mx.com.cetech.javaWeb.persistence.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import mx.com.cetech.javaWeb.commons.exception.CustomExceptionEnum;
import mx.com.cetech.javaWeb.commons.exception.ProjectExceptionBuilder;
import mx.com.cetech.javaWeb.persistence.EntityTypeEnum;
import mx.com.cetech.javaWeb.persistence.FactoryConnection;
import mx.com.cetech.javaWeb.persistence.ProductDOAttribsEnum;
import mx.com.cetech.javaWeb.persistence.UserDOAttribsEnum;
import mx.com.cetech.javaWeb.persistence.model.ProductDO;
import mx.com.cetech.javaWeb.persistence.model.UserDO;

public abstract class AbstractBaseDAO<T extends Serializable> {

	private static final Logger LOGGER = Logger.getLogger(AbstractBaseDAO.class);

	private Connection connection;

	protected EntityTypeEnum entityType;

	public AbstractBaseDAO(EntityTypeEnum entityType) {
		this.entityType = entityType;
	}

	protected List<ProductDO> buildProductDO(ResultSet rs) throws SQLException {

		List<ProductDO> list = new ArrayList<ProductDO>();

		while (rs.next()) {

			ProductDO item = new ProductDO();
			item.setId(rs.getString(ProductDOAttribsEnum.ID.getAttrib()));
			item.setName(rs.getString(ProductDOAttribsEnum.NAME.getAttrib()));
			item.setDescription(rs.getString(ProductDOAttribsEnum.DESCRIPTION.getAttrib()));
			item.setQuantity(rs.getInt(ProductDOAttribsEnum.QUANTITY.getAttrib()));
			item.setBuyPrice(rs.getDouble(ProductDOAttribsEnum.BUY_PRICE.getAttrib()));
			item.setSellPrice(rs.getDouble(ProductDOAttribsEnum.SELL_PRICE.getAttrib()));
			item.setDate(rs.getDate(ProductDOAttribsEnum.DATE.getAttrib()));
			list.add(item);

		}
		return list;
	}

	protected List<UserDO> buildUserDO(ResultSet rs) throws SQLException {
		List<UserDO> list = new ArrayList<UserDO>();

		while (rs.next()) {

			UserDO user = new UserDO();

			user.setId(rs.getInt(UserDOAttribsEnum.ID.getAttrib()));
			user.setPass(rs.getString(UserDOAttribsEnum.PASS.getAttrib()));
			user.setType(rs.getInt(UserDOAttribsEnum.TYPE.getAttrib()));
			user.setUserName(rs.getString(UserDOAttribsEnum.NAME.getAttrib()));

			list.add(user);

		}

		return list;
	}

	protected Connection getConnection() throws SQLException {
		if (connection == null|| connection.isClosed()) {
			connection = FactoryConnection.buildConnection();
		}
		return connection;
	}

	protected void closeConnection() {
		closeConnection(connection);
	}

	protected void closeConnection(Connection conn) {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				LOGGER.error(e.getMessage(), e);
				throw ProjectExceptionBuilder.buildException(CustomExceptionEnum.DB_CONNECTION_CLOSE_ERROR, e);
			}
			finally
			{
				conn = null;
			}
		}
	}

	public abstract void insertNewRecord(T entity);

	public abstract void deleteRecord(T entity);

	public abstract void updateRecord(Serializable id, T newEntity);

	public abstract List<T> findAll();

}
