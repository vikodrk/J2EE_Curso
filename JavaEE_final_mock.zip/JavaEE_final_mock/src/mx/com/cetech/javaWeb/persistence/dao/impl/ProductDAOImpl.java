package mx.com.cetech.javaWeb.persistence.dao.impl;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;

import mx.com.cetech.javaWeb.commons.exception.CustomExceptionEnum;
import mx.com.cetech.javaWeb.commons.exception.ProjectExceptionBuilder;
import mx.com.cetech.javaWeb.persistence.EntityTypeEnum;
import mx.com.cetech.javaWeb.persistence.ProductDOQueries;
import mx.com.cetech.javaWeb.persistence.dao.AbstractBaseDAO;
import mx.com.cetech.javaWeb.persistence.dao.IBaseDAO;
import mx.com.cetech.javaWeb.persistence.model.ProductDO;

public class ProductDAOImpl extends AbstractBaseDAO<ProductDO> implements IBaseDAO<ProductDO> {

	private static final Logger LOGGER = Logger.getLogger(ProductDAOImpl.class);

	public ProductDAOImpl() {
		super(EntityTypeEnum.USER);
	}

	@Override
	public ProductDO findById(Serializable id) {
		ProductDO product = new ProductDO();
		String theId = String.valueOf(id);
		Connection connection = null;
		try {
			connection = getConnection();
			PreparedStatement ps = connection.prepareStatement(ProductDOQueries.FIND_BY_ID.getQuery());
			ps.setString(1, theId);
			List<ProductDO> list = buildProductDO(ps.executeQuery());
			if (list.size() <= 0 || list.size() > 1) {
				ProjectExceptionBuilder.buildException(CustomExceptionEnum.DB_ERROR_RESULT);
			}
			product = list.get(0);
		} catch (SQLException e) {
			LOGGER.error(e.getMessage(), e);
			throw ProjectExceptionBuilder.buildException(CustomExceptionEnum.DB_ERROR, e);
		} finally {
			closeConnection(connection);
		}

		return product;
	}

	@Override
	public void insertNewRecord(ProductDO entity) {

		Connection conn = null;
		PreparedStatement ps = null;

		try {
			conn = getConnection();
			ps = conn.prepareStatement(ProductDOQueries.INSERT.getQuery());
			ps.setString(1, entity.getId());
			ps.setString(2, entity.getName());
			ps.setString(3, entity.getDescription());
			ps.setInt(4, entity.getQuantity());
			ps.setDouble(5, entity.getBuyPrice());
			ps.setDouble(6, entity.getSellPrice());
			ps.setDate(7, new Date(Calendar.getInstance().getTimeInMillis()));
			ps.executeUpdate();
		} catch (SQLIntegrityConstraintViolationException e) {
			LOGGER.warn(e.getMessage(), e);
			throw ProjectExceptionBuilder.buildException(CustomExceptionEnum.DB_ERROR_ENTITY_EXISTS, e);
		} catch (SQLException e) {
			LOGGER.error(e.getMessage(), e);
			throw ProjectExceptionBuilder.buildException(CustomExceptionEnum.DB_ERROR, e);
		} finally {
			closeConnection(conn);
		}

	}

	@Override
	public void deleteRecord(ProductDO entity) {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			con = getConnection();
			ps = con.prepareStatement(ProductDOQueries.DELETE.getQuery());
			ps.setString(1, entity.getId());
			ps.executeUpdate();

		} catch (SQLException e) {
			LOGGER.error(e.getMessage(), e);
			throw ProjectExceptionBuilder.buildException(CustomExceptionEnum.DB_ERROR, e);
		}

		finally {
			closeConnection(con);
		}

	}

	@Override
	public void updateRecord(Serializable id, ProductDO newEntity) {
		Connection conn = null;
		PreparedStatement ps = null;

		try {
			conn = getConnection();
			ps = conn.prepareStatement(ProductDOQueries.UPDATE.getQuery());
			ps.setString(1, newEntity.getId());
			ps.setString(2, newEntity.getName());
			ps.setString(3, newEntity.getDescription());
			ps.setInt(4, newEntity.getQuantity());
			ps.setDouble(5, newEntity.getBuyPrice());
			ps.setDouble(6, newEntity.getSellPrice());
			ps.setDate(7, new Date(Calendar.getInstance().getTimeInMillis()));
			ps.setString(8, String.valueOf(id));
			ps.executeUpdate();

		} catch (SQLException e) {
			LOGGER.error(e.getMessage(), e);
			throw ProjectExceptionBuilder.buildException(CustomExceptionEnum.DB_ERROR, e);
		}

		finally {
			closeConnection(conn);
		}

	}

	@Override
	public List<ProductDO> findAll() {
		Connection conn = null;
		PreparedStatement ps = null;
		List<ProductDO> list = null;

		try {
			conn = getConnection();
			ps = conn.prepareStatement(ProductDOQueries.FIND_ALL.getQuery());

			list = buildProductDO(ps.executeQuery());
		} catch (SQLException e) {
			LOGGER.error(e.getMessage(), e);
			throw ProjectExceptionBuilder.buildException(CustomExceptionEnum.DB_ERROR, e);
		}

		finally {
			closeConnection(conn);
		}

		return list;
	}

}
