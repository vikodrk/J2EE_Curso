package mx.com.cetech.javaWeb.persistence.dao.impl;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

import org.apache.log4j.Logger;

import mx.com.cetech.javaWeb.commons.exception.CustomExceptionEnum;
import mx.com.cetech.javaWeb.commons.exception.ProjectExceptionBuilder;
import mx.com.cetech.javaWeb.persistence.EntityTypeEnum;
import mx.com.cetech.javaWeb.persistence.UserDOQueries;
import mx.com.cetech.javaWeb.persistence.dao.AbstractBaseDAO;
import mx.com.cetech.javaWeb.persistence.dao.IBaseDAO;
import mx.com.cetech.javaWeb.persistence.model.UserDO;

public class UserDAOImpl extends AbstractBaseDAO<UserDO> implements IBaseDAO<UserDO> {

	private static final Logger LOGGER = Logger.getLogger(UserDAOImpl.class);

	public UserDAOImpl() {
		super(EntityTypeEnum.USER);
	}

	@Override
	public UserDO findById(Serializable id) {
		UserDO user = new UserDO();
		String theId = String.valueOf(id);
		Connection connection = null;
		try {
			connection = getConnection();
			PreparedStatement ps = connection.prepareStatement(UserDOQueries.FIND_BY_ID.getQuery());
			ps.setInt(1, Integer.parseInt(theId));
			List<UserDO> list = buildUserDO(ps.executeQuery());
			if (list.size() <= 0 || list.size() > 1) {
				ProjectExceptionBuilder.buildException(CustomExceptionEnum.DB_ERROR_RESULT);
			}
			user = list.get(0);
		} catch (SQLException e) {
			LOGGER.error(e.getMessage(), e);
			throw ProjectExceptionBuilder.buildException(CustomExceptionEnum.DB_ERROR, e);
		} finally {
			closeConnection(connection);
		}

		return user;
	}

	@Override
	public void insertNewRecord(UserDO entity) {

		Connection conn = null;
		PreparedStatement ps = null;

		try {
			conn = getConnection();
			ps = conn.prepareStatement(UserDOQueries.INSERT.getQuery());
			ps.setString(1, entity.getUserName());
			ps.setString(2, entity.getPass());
			ps.setInt(3, entity.getType());
			ps.executeUpdate();
		} catch (SQLIntegrityConstraintViolationException e) {
			LOGGER.warn(e.getMessage(), e);
			throw ProjectExceptionBuilder.buildException(CustomExceptionEnum.DB_ERROR_ENTITY_EXISTS, e);
		} catch (SQLException e) {
			LOGGER.error(e.getMessage(), e);
			throw ProjectExceptionBuilder.buildException(CustomExceptionEnum.DB_ERROR, e);
		} finally {
			closeConnection(conn);
		}

	}

	@Override
	public void deleteRecord(UserDO entity) {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			con = getConnection();
			ps = con.prepareStatement(UserDOQueries.DELETE.getQuery());
			ps.setInt(1, entity.getId());
			ps.executeUpdate();

		} catch (SQLException e) {
			LOGGER.error(e.getMessage(), e);
			throw ProjectExceptionBuilder.buildException(CustomExceptionEnum.DB_ERROR, e);
		}

		finally {
			closeConnection(con);
		}

	}

	@Override
	public void updateRecord(Serializable id, UserDO newEntity) {
		Connection conn = null;
		PreparedStatement ps = null;
		String theId = String.valueOf(id);
		try {
			conn = getConnection();
			ps = conn.prepareStatement(UserDOQueries.UPDATE.getQuery());
			ps.setString(1, newEntity.getUserName());
			ps.setString(2, newEntity.getPass());
			ps.setInt(3, newEntity.getType());
			ps.setInt(4, Integer.parseInt(theId));
			ps.executeUpdate();

		} catch (SQLException e) {
			LOGGER.error(e.getMessage(), e);
			throw ProjectExceptionBuilder.buildException(CustomExceptionEnum.DB_ERROR, e);
		}

		finally {
			closeConnection(conn);
		}

	}

	@Override
	public List<UserDO> findAll() {
		Connection conn = null;
		PreparedStatement ps = null;
		List<UserDO> list = null;

		try {
			conn = getConnection();
			ps = conn.prepareStatement(UserDOQueries.FIND_ALL.getQuery());

			list = buildUserDO(ps.executeQuery());
		} catch (SQLException e) {
			LOGGER.error(e.getMessage(), e);
			throw ProjectExceptionBuilder.buildException(CustomExceptionEnum.DB_ERROR, e);
		}

		finally {
			closeConnection(conn);
		}

		return list;
	}

}
