package mx.com.cetech.javaWeb.persistence;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

import mx.com.cetech.javaWeb.commons.exception.CustomExceptionEnum;
import mx.com.cetech.javaWeb.commons.exception.ProjectExceptionBuilder;
import mx.com.cetech.javaWeb.commons.utils.ProjectStringUtils;

public final class FactoryConnection {

	private static final Logger LOGGER = Logger.getLogger(FactoryConnection.class);

	private static final String DB_HOST = "db.host";
	private static final String DB_PORT = "db.port";
	private static final String DB_DATA_BASE_NAME = "db.dataBaseName";
	private static final String DB_USER = "db.user";
	private static final String DB_PASS = "db.pass";

	public static Connection buildConnection() {
		Connection conn = null;

		Properties properties = new Properties();
		InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("db_properties.properties");

		try {
			properties.load(is);
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			String url = ProjectStringUtils.concatenateStrings("jdbc:mysql://", properties.getProperty(DB_HOST), ":",
					properties.getProperty(DB_PORT), "/", properties.getProperty(DB_DATA_BASE_NAME));
			String user = properties.getProperty(DB_USER);
			String password = properties.getProperty(DB_PASS);
			LOGGER.debug("DB url: " + url);
			conn = DriverManager.getConnection(url, user, password);

		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
			throw ProjectExceptionBuilder.buildException(CustomExceptionEnum.DB_FILE_NOT_FOUND, e);
		} catch (InstantiationException e) {
			LOGGER.error(e.getMessage(), e);
			throw ProjectExceptionBuilder.buildException(CustomExceptionEnum.DB_INSTANCIATION_ERROR, e);
		} catch (IllegalAccessException e) {
			LOGGER.error(e.getMessage(), e);
			throw ProjectExceptionBuilder.buildException(CustomExceptionEnum.DB_ILLEGAR_ACCESS_ERROR, e);
		} catch (ClassNotFoundException e) {
			LOGGER.error(e.getMessage(), e);
			throw ProjectExceptionBuilder.buildException(CustomExceptionEnum.DB_DRIVER_NOT_FOUND, e);
		} catch (SQLException e) {
			LOGGER.error(e.getMessage(), e);
			throw ProjectExceptionBuilder.buildException(CustomExceptionEnum.DB_CONNECTION_ERROR, e);
		}

		return conn;
	}

}
