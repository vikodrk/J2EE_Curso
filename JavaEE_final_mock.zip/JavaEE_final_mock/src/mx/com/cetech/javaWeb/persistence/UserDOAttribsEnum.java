package mx.com.cetech.javaWeb.persistence;

public enum UserDOAttribsEnum implements IAttribs{
	
	ID("ID_USUARIO"),
	
	NAME("NOMBRE_USUARIO"),
	
	PASS("PASS"),
	
	TYPE("TIPO_USUARIO")
	
	;
	private String attrib;
	
	private UserDOAttribsEnum(String attrib)
	{
		this.attrib=attrib;
	}
	
	public String getAttrib()
	{
		return attrib;
	}

}
