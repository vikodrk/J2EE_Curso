package mx.com.cetech.javaWeb.persistence;

public enum EntityTypeEnum {

	USER,

	PRODUCT;
}
