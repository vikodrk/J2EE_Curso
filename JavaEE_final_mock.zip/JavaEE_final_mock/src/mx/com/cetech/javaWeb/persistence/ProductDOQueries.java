package mx.com.cetech.javaWeb.persistence;

public enum ProductDOQueries implements IQueries {

	INSERT("INSERT INTO INVENTARIO (ID_PRODUCTO, NOMBRE_PRODUCTO, DESCRIPCION_PRODUCTO, CANTIDAD, PRECIO_COMPRA, PRECIO_VENTA, FECHA_REGISTRO) VALUES (?,?,?,?,?,?,?)"),

	UPDATE("UPDATE INVENTARIO SET ID_PRODUCTO=?, NOMBRE_PRODUCTO=?, DESCRIPCION_PRODUCTO=?, CANTIDAD=?, PRECIO_COMPRA=?, PRECIO_VENTA=?, FECHA_REGISTRO=? WHERE ID_PRODUCTO = ?"),

	DELETE("DELETE FROM INVENTARIO WHERE ID_PRODUCTO = ?"),

	FIND_ALL("SELECT * FROM INVENTARIO"),

	FIND_BY_ID("SELECT * FROM INVENTARIO WHERE ID_PRODUCTO = ?");

	private String query;

	private ProductDOQueries(String query) {
		this.query = query;
	}

	@Override
	public String getQuery() {
		return query;
	}

}
