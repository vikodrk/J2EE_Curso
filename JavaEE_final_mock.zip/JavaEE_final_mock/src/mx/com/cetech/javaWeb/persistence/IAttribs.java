package mx.com.cetech.javaWeb.persistence;

public interface IAttribs {
	
	String getAttrib();

}
