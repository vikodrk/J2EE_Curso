package mx.com.cetech.javaWeb.persistence;

public enum UserDOQueries implements IQueries {

	INSERT("INSERT INTO USUARIOS (NOMBRE_USUARIO, PASS, TIPO_USUARIO) VALUES (?,?,?)"),

	UPDATE("UPDATE USUARIOS SET NOMBRE_USUARIO = ?, PASS = ?, TIPO_USUARIO = ? WHERE ID_USUARIO = ?"),

	DELETE("DELETE FROM USUARIOS WHERE ID_USUARIO = ?"),

	FIND_ALL("SELECT * FROM USUARIOS"),

	FIND_BY_ID("SELECT * FROM USUARIOS WHERE ID_USUARIO = ?");

	private String query;

	private UserDOQueries(String query) {
		this.query = query;
	}

	@Override
	public String getQuery() {
		return query;
	}

}
