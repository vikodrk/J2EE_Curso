package mx.com.cetech.javaWeb.persistence.dao;

import java.io.Serializable;
import java.util.List;

public interface IBaseDAO<T extends Serializable> {

	void insertNewRecord(T entity);

	void updateRecord(Serializable id, T entity);

	void deleteRecord(T entity);

	List<T> findAll();

	T findById(Serializable id);

}
