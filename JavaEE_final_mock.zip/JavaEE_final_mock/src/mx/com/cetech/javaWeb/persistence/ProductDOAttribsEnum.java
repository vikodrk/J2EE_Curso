package mx.com.cetech.javaWeb.persistence;

public enum ProductDOAttribsEnum implements IAttribs {

	ID("ID_PRODUCTO"),

	NAME("NOMBRE_PRODUCTO"),

	DESCRIPTION("DESCRIPCION_PRODUCTO"),

	QUANTITY("CANTIDAD"),

	BUY_PRICE("PRECIO_COMPRA"),

	SELL_PRICE("PRECIO_VENTA"),

	DATE("FECHA_REGISTRO")

	;
	private String attrib;

	private ProductDOAttribsEnum(String attrib) {
		this.attrib = attrib;
	}

	@Override
	public String getAttrib() {
		return attrib;
	}

}
