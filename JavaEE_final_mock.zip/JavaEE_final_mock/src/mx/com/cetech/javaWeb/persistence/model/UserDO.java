package mx.com.cetech.javaWeb.persistence.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class UserDO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7723893793765817849L;

	private Integer id;
	private String userName;
	private String pass;
	private Integer type;

	public Integer getId() {
		return id;
	}

	public String getUserName() {
		return userName;
	}

	public String getPass() {
		return pass;
	}

	public Integer getType() {
		return type;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();

		builder.append(id).append(" - ").append(userName).append(" - ").append(type);

		return builder.toString();
	}

	@Override
	public boolean equals(Object obj) {
		boolean flag = false;

		if (obj != null) {

			if (obj == this) {
				flag = true;
			} else if (obj.getClass() == this.getClass()) {
				flag = new EqualsBuilder().append(id, ((UserDO) obj).id).isEquals();
			}

		}

		return flag;
	}

	@Override
	public int hashCode() {
		HashCodeBuilder builder = new HashCodeBuilder();

		builder.append(id);

		return builder.build();
	}

}
