package mx.com.cetech.javaWeb.persistence.model;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class ProductDO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2310699719874285406L;

	private String id;

	private String name;

	private String description;

	private Integer quantity;

	private Double buyPrice;

	private Double sellPrice;

	private Date date;

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public Double getBuyPrice() {
		return buyPrice;
	}

	public Double getSellPrice() {
		return sellPrice;
	}

	public Date getDate() {
		return date == null ? null : (Date) date.clone();
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public void setBuyPrice(Double buyPrice) {
		this.buyPrice = buyPrice;
	}

	public void setSellPrice(Double sellPrice) {
		this.sellPrice = sellPrice;
	}

	public void setDate(Date date) {
		this.date = date == null ? null : (Date) date.clone();
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();

		builder.append(id).append(" - ").append(name);

		return builder.toString();
	}

	@Override
	public boolean equals(Object obj) {
		boolean flag = false;

		if (obj != null) {
			if (obj == this) {
				flag = true;
			} else if (obj.getClass() == this.getClass()) {
				flag = new EqualsBuilder().append(id, ((ProductDO) obj).id).isEquals();
			}
		}

		return flag;
	}

	@Override
	public int hashCode() {
		HashCodeBuilder builder = new HashCodeBuilder();
		builder.append(id);
		return builder.build();
	}

}
